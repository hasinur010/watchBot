{
    "manifest_version": 2,
    "name": "My Cool Extension",
    "version": "0.1",
    "background": {
      "scripts": ["background.js"]
    },
    "content_scripts": [
      {
        "matches": [
          "<all_urls>"
        ],
        "js": ["jquery-2.1.3.min.js", "content.js"]
      }
    ],
    "browser_action": {
      "default_icon": "icon.png"
    }
  }