
/*

    Author: MD HASINUR RAHMAN
    Email: hasinur010@gmail.com
    All rights are preserved.

*/
	
	var persons = [
		{
			name : "Hasinur_",
			color: "green"
		},
		{
			name : "I_love_ProParThinkNot",
			color: "blue"
		},
		{
			name : "halfblindprince",
			color: "orange"
		},
		{
			name : "tanus_era",
			color: "purple"
		},
		{
			name : "ovis96",
			color: "red"
		},
	];


	var pref = "https://codeforces.com/api/user.status?handle=";
	var suff = "&from=1&count=100000";
	var AC=[];
	function paint(name,color){
		var userName = name;
		var link = pref + userName + suff;
		var submissions;
		
		
		$.get(link, function(data, status){
			submissions = data.result;
			
			//console.log(submissions);
			for(i=0;i<submissions.length ; i++){
				//console.log(submissions[i]);
				problem = submissions[i]["problem"];
				//console.log(problem);
				problemLink = "http://codeforces.com/problemset/problem/"+problem["contestId"]+"/"+problem["index"];
				//console.log(problemLink);
				//$("[href='default.htm']"
				var ifExists = "tr:has([href='"+problemLink+"'])";
				if(submissions[i]["verdict"]=="OK" &&  AC[problemLink]!="AC"){
					$(ifExists).css("background-color", color);
					AC[problemLink] = "AC";
				}
				else if( AC[problemLink]!="AC") {
					//$(ifExists).css("background-color","#ffc107");
				}
			}
		});
	}


	$(document).ready(function(){

			for(j=0;j<persons.length;j++) paint( persons[j].name, persons[j].color );
		
	});

